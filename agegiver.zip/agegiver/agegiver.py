import time
print("enter your birth year\n")
a=int(input())
print("enter current year\n")
b=int(input())
c=b-a
print("you're approximately",c-1," to ",c," years old")
time.sleep(10)