python 3.11 or better
4 kilobytes of Free space on hard disk