requirements:
python 3.11 or better
40 kilobytes of Free space on hard disk