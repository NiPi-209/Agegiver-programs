import time
print("please select language / valitse kieli / välj språk / bitte Sprache auswählen")
print("")
print("1. english \n2. suomi\n3. sverige\n4. deutsche\n")
lang=input()
if lang=="1":
    from languages.english import *
if lang=="2":
    from languages.finnish import *
if lang=="3":
    from languages.swedish import *
if lang=="4":
    from languages.german import *
print(welcome,"\n")
print(year1,"\n")
a=int(input())
print(month1,"\n")
e=int(input())
print(day1,"\n")
g=int(input())
print(year2,"\n")
b=int(input())
print(month2,"\n")
f=int(input())
print(day2,"\n")
h=int(input())
if e >= 13 or f >= 13 or g >= 33 or h >= 33:
    print (badvalue)
    time.sleep(50)
else:
    c=(b-a)-1
    if f>=e and g>=h:
        c=c+1
    print(guess1,c,guess2)
    time.sleep(500)